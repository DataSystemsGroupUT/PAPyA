class joinTuple:
    def join_tuple_string(string_tuple) -> str:
        return '.'.join(string_tuple)